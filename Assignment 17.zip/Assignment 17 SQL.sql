Create DATABASE tips_db;
use tips_db;
create table tips(
total_bill decimal(10,2),
tip decimal(10,2),
sex varchar(10),
smoker varchar(10),
day varchar(10),
time varchar(10),
size int
);
select * from tips;
select * from tips where day='sun' and smoker='yes';
select * from tips where tip>5 and total_bill<25;
select * from tips where day='sun' and smoker='yes';
select * from tips where sex='Female' and time='Dinner';
select * from tips where size>=4 and day='sat';
select * from tips order by total_bill desc limit 10;
select * from tips where day='Fri' order by tip ASC Limit 5;
select * from tips where tip between 3 and 6 and smoker='No';
select * from tips limit 10;
select * from tips limit 10 offset 10;
select * from tips where total_bill>40 order by tip desc limit 5;
select * from tips where time="lunch" and tip>total_bill*0.20;
SELECT COUNT(*) AS total_records FROM tips;
select sum(tip) as total_tip from tips;
select avg(total_bill) as average_bill from tips;
SELECT MAX(tip) AS maximum_tip, MIN(tip) AS minimum_tip FROM tips;
SELECT sex, AVG(tip) AS average_tip FROM tips GROUP BY sex;
SELECT smoker, COUNT(*) AS total_people FROM tips GROUP BY smoker;
SELECT day, AVG(total_bill) AS average_bill FROM tips GROUP BY day;
SELECT day, SUM(tip) AS total_tip FROM tips GROUP BY day ORDER BY total_tip DESC;
SELECT day, time, AVG(size) AS average_size FROM tips GROUP BY day, time;



